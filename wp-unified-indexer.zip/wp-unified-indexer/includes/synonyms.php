<?php
/**
 * WP Unified Indexer – Synonyms
 * @version 1.0.0 (2025-08-13)
 * @description Mapeamento e normalização de sinônimos para indexação semântica.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WPUI_Synonyms {

    /**
     * Retorna o mapa de sinônimos no formato ['termo' => ['sin1', 'sin2', ...]]
     */
    public static function get_map() : array {
        global $wpdb;
        $table = $wpdb->prefix . 'wpui_synonyms';
        $rows = $wpdb->get_results( "SELECT term, synonyms FROM {$table}", ARRAY_A );
        $map = [];

        foreach ( $rows as $r ) {
            $list = json_decode( $r['synonyms'] ?: '[]', true );
            if ( is_array( $list ) ) {
                $map[ $r['term'] ] = array_values( array_filter( array_map( 'strval', $list ) ) );
            }
        }

        return $map;
    }

    /**
     * Normaliza o texto e expande com sinônimos
     */
    public static function normalize_with_synonyms( string $text ) : array {
        $text = mb_strtolower( wp_strip_all_tags( $text ), 'UTF-8' );
        $text = preg_replace( '/[^\p{L}\p{N}\s\.\-]/u', ' ', $text );
        $text = preg_replace( '/\s+/u', ' ', $text );
        $text = trim( $text );

        $tokens = array_filter( explode( ' ', $text ) );
        $map = self::get_map();
        $out = [];

        foreach ( $tokens as $t ) {
            $out[] = $t;
            if ( isset( $map[ $t ] ) ) {
                foreach ( $map[ $t ] as $alt ) {
                    $out[] = $alt;
                }
            }
        }

        return array_values( array_unique( $out ) );
    }
}
