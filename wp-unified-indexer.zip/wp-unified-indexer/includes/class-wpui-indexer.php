<?php
/**
 * WP Unified Indexer – Core Indexer
 * @version 1.0.0 (2025-08-13)
 * @description Classe principal de indexação. Parser robusto, normalização, agendamento e persistência.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WPUI_Indexer {

    /**
     * Agenda indexação via cron (evita travar o save_post).
     */
    public static function schedule_index( int $post_id ) : void {
        if ( $post_id <= 0 ) return;

        $ts = wp_next_scheduled( 'wpui_index_post_event', [ $post_id ] );
        if ( $ts ) wp_unschedule_event( $ts, 'wpui_index_post_event', [ $post_id ] );

        wp_schedule_single_event( time() + 5, 'wpui_index_post_event', [ $post_id ] );
    }

    /**
     * Indexa um post (modo full ou itens numerados).
     */
    public static function index_post( int $post_id ) : void {
        $post = get_post( $post_id );
        if ( ! $post || 'publish' !== $post->post_status ) return;

        $settings = get_option( WPUI_OPTION_KEY, [] );
        $global_mode = $settings['index_mode'] ?? 'auto';
        $start_number = max( 0, (int) ( $settings['start_number'] ?? 5 ) );
        $mode = get_post_meta( $post_id, '_wpui_mode', true );

        if ( ! in_array( $mode, ['full','items'], true ) ) {
            $mode = $global_mode;
        }

        $content = apply_filters( 'the_content', $post->post_content );

        if ( $mode === 'auto' ) {
            $mode = self::has_numbered_h2( $content, $start_number ) ? 'items' : 'full';
        }

        WPUI_DB::clear_post( $post_id );
        $rows = [];

        if ( $mode === 'full' ) {
            $plain = wp_strip_all_tags( $content );
            $terms = WPUI_Synonyms::normalize_with_synonyms( $plain );
            foreach ( $terms as $t ) {
                $rows[] = [
                    'item_key' => 'full',
                    'heading' => get_the_title( $post_id ),
                    'content' => $plain,
                    'term' => $t,
                ];
            }
        } else {
            $items = self::get_items_from_content( $content, $start_number );
            $order = 0;
            foreach ( $items as $it ) {
                $terms = WPUI_Synonyms::normalize_with_synonyms( $it['heading'] . ' ' . $it['content'] );
                foreach ( $terms as $t ) {
                    $rows[] = [
                        'item_key' => $it['key'],
                        'heading' => $it['heading'],
                        'content' => $it['content'],
                        'term' => $t,
                        'order_index' => $order,
                    ];
                }
                $order++;
            }
        }

        if ( $rows ) {
            WPUI_DB::insert_items( $post_id, $rows );
        }

        WPUI_DB::upsert_post_meta_row( $post_id, $mode );

        if ( ! empty( $settings['logging'] ) ) {
            error_log( "[WPUI] Post $post_id indexado com modo $mode e " . count( $rows ) . " termos." );
        }

        do_action( 'wpui_indexed_post', $post_id, [
            'mode' => $mode,
            'count' => count( $rows ),
        ] );
    }

    /**
     * Remove dados indexados de um post.
     */
    public static function deindex_post( int $post_id ) : void {
        WPUI_DB::clear_post( $post_id );
    }

    /**
     * Verifica se há H2 numerado ≥ $start.
     */
    private static function has_numbered_h2( string $html, int $start = 5 ) : bool {
        $dom = self::make_dom( $html );
        $xpath = new DOMXPath( $dom );
        $nodes = $xpath->query('//h2');
        foreach ( $nodes as $n ) {
            $txt = trim( self::node_text( $n ) );
            $num = self::extract_leading_number( $txt );
            if ( $num !== null && $num >= $start ) return true;
        }
        return false;
    }

    /**
     * Extrai itens numerados do conteúdo.
     */
    public static function get_items_from_content( string $html, int $start = 5 ) : array {
        $dom = self::make_dom( $html );
        $xpath = new DOMXPath( $dom );
        $h2s = iterator_to_array( $xpath->query('//h2') );
        $indices = [];

        foreach ( $h2s as $h2 ) {
            $txt = trim( self::node_text( $h2 ) );
            if ( $txt === '' ) continue;
            $primary = self::extract_leading_number( $txt );
            if ( $primary === null || $primary < $start ) continue;
            $key = self::extract_full_key( $txt ) ?: (string) $primary;
            $indices[] = [
                'node' => $h2,
                'key' => $key,
                'heading' => $txt,
            ];
        }

        $items = [];
        $count = count( $indices );
        for ( $i = 0; $i < $count; $i++ ) {
            $current = $indices[$i]['node'];
            $next = ( $i + 1 < $count ) ? $indices[$i+1]['node'] : null;
            $content = self::collect_between( $current, $next );
            $items[] = [
                'key' => $indices[$i]['key'],
                'heading' => $indices[$i]['heading'],
                'content' => $content,
            ];
        }

        return $items;
    }

    // --- Helpers DOM/Texto ---

    private static function make_dom( string $html ) : DOMDocument {
        $dom = new DOMDocument( '1.0', 'UTF-8' );
        libxml_use_internal_errors( true );
        $html = '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">' . $html;
        $dom->loadHTML( $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NOERROR | LIBXML_NOWARNING );
        libxml_clear_errors();
        return $dom;
    }

    private static function node_text( DOMNode $n ) : string {
        return trim( preg_replace( '/\s+/', ' ', $n->textContent ?? '' ) );
    }

    private static function extract_leading_number( string $s ) : ?int {
        if ( preg_match( '/^\s*(\d+)(?:\d+)?[\s\)\.\-]/u', $s, $m ) ) {
            return intval( $m[1] );
        }
        if ( preg_match( '/^\s*(\d+)\s*/u', $s, $m ) ) {
            return intval( $m[1] );
        }
        return null;
    }

    private static function extract_full_key( string $s ) : ?string {
        if ( preg_match( '/^\s*(\d+(?:[.,]\d+)?)/u', $s, $m ) ) {
            return str_replace( ',', '.', $m[1] );
        }
        return null;
    }

    private static function collect_between( DOMNode $fromNode, ?DOMNode $toNode ) : string {
        $html = '';
        for ( $n = $fromNode->nextSibling; $n && $n !== $toNode; $n = $n->nextSibling ) {
            $html .= self::outer_html( $n );
        }
        return wp_kses_post( trim( $html ) );
    }

    private static function outer_html( DOMNode $node ) : string {
        $doc = $node->ownerDocument;
        return $doc->saveHTML( $node ) ?: '';
    }
}
