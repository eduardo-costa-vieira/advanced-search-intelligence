<?php
/**
 * WP Unified Indexer – DB Layer
 * @version 1.0.0 (2025-08-13)
 * @description Criação e manipulação segura das tabelas wpui_posts, wpui_items e wpui_synonyms.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WPUI_DB {

    /**
     * Cria as tabelas do plugin com charset/collate e índices otimizados.
     */
    public static function install_tables() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();
        $items   = $wpdb->prefix . 'wpui_items';
        $posts   = $wpdb->prefix . 'wpui_posts';
        $syn     = $wpdb->prefix . 'wpui_synonyms';

        $sql_items = "CREATE TABLE {$items} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            item_key VARCHAR(50) NOT NULL,
            heading TEXT NULL,
            content LONGTEXT NULL,
            term TEXT NULL,
            order_index INT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY post_idx (post_id),
            KEY item_key_idx (item_key(20)),
            KEY term_idx (term(191))
        ) $charset;";

        $sql_posts = "CREATE TABLE {$posts} (
            post_id BIGINT UNSIGNED NOT NULL,
            mode VARCHAR(10) NOT NULL DEFAULT 'auto',
            indexed_at DATETIME NULL,
            PRIMARY KEY (post_id)
        ) $charset;";

        $sql_syn = "CREATE TABLE {$syn} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            term VARCHAR(191) NOT NULL,
            synonyms LONGTEXT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY term_unique (term)
        ) $charset;";

        dbDelta( $sql_items );
        dbDelta( $sql_posts );
        dbDelta( $sql_syn );
    }

    /**
     * Remove dados indexados de um post.
     */
    public static function clear_post( $post_id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'wpui_items';
        $wpdb->delete( $table, [ 'post_id' => (int) $post_id ], [ '%d' ] );

        $p = $wpdb->prefix . 'wpui_posts';
        $wpdb->delete( $p, [ 'post_id' => (int) $post_id ], [ '%d' ] );
    }

    /**
     * Atualiza ou insere metadados de indexação do post.
     */
    public static function upsert_post_meta_row( $post_id, $mode ) {
        global $wpdb;
        $p = $wpdb->prefix . 'wpui_posts';
        $wpdb->replace(
            $p,
            [
                'post_id'    => (int) $post_id,
                'mode'       => $mode,
                'indexed_at' => current_time( 'mysql' ),
            ],
            [ '%d', '%s', '%s' ]
        );
    }

    /**
     * Insere os itens indexados do post.
     */
    public static function insert_items( $post_id, array $rows ) {
        global $wpdb;
        $table = $wpdb->prefix . 'wpui_items';

        foreach ( $rows as $i => $r ) {
            $wpdb->insert(
                $table,
                [
                    'post_id'     => (int) $post_id,
                    'item_key'    => $r['item_key'],
                    'heading'     => $r['heading'],
                    'content'     => $r['content'],
                    'term'        => $r['term'],
                    'order_index' => (int) ( $r['order_index'] ?? $i ),
                ],
                [ '%d', '%s', '%s', '%s', '%d' ]
            );
        }
    }
}
