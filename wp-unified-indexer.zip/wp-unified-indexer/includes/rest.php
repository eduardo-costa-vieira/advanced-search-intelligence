<?php
/**
 * WP Unified Indexer – REST API
 * @version 1.0.0 (2025-08-13)
 * @description Endpoints REST para reindexação e busca semântica. Sanitização e segurança aplicadas.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WPUI_REST {

    public static function register_routes() {

        // Endpoint: Reindexar posts via POST
        register_rest_route( 'wpui/v1', '/reindex', [
            'methods' => 'POST',
            'permission_callback' => function () {
                return current_user_can( WPUI_CAP );
            },
            'callback' => function ( WP_REST_Request $req ) {
                $ids = array_map( 'intval', (array) $req->get_param( 'post_ids' ) );
                $ok = [];

                foreach ( $ids as $id ) {
                    WPUI_Indexer::schedule_index( $id );
                    $ok[] = $id;
                }

                return rest_ensure_response( [ 'scheduled' => $ok ] );
            }
        ] );

        // Endpoint: Buscar termos via GET
        register_rest_route( 'wpui/v1', '/search', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => function ( WP_REST_Request $req ) {
                global $wpdb;

                $q = trim( (string) $req->get_param( 'q' ) );
                if ( $q === '' ) return rest_ensure_response( [] );

                $terms = WPUI_Synonyms::normalize_with_synonyms( $q );
                if ( empty( $terms ) ) return rest_ensure_response( [] );

                $in = implode( ',', array_fill( 0, count( $terms ), '%s' ) );
                $table = $wpdb->prefix . 'wpui_items';

                $sql = "SELECT post_id, item_key, heading, SUBSTRING(content,1,300) AS snippet
                        FROM {$table}
                        WHERE term IN ($in)
                        ORDER BY post_id, order_index
                        LIMIT 100";

                $rows = $wpdb->get_results( $wpdb->prepare( $sql, $terms ), ARRAY_A );
                return rest_ensure_response( $rows );
            }
        ] );
    }
}
