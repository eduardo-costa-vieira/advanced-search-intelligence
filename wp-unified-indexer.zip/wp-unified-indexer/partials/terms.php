<?php
/**
 * WPUI Admin Partial – Terms
 * @version 1.0.0
 * @description Visualização de termos indexados por post.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;
$items_table = $wpdb->prefix . 'wpui_items';

$post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;
$terms = [];

if ($post_id > 0) {
    $terms = $wpdb->get_results($wpdb->prepare("SELECT item_key, heading, term FROM {$items_table} WHERE post_id = %d ORDER BY order_index ASC", $post_id), ARRAY_A);
}
?>

<h2>Termos Indexados</h2>
<form method="get">
    <input type="hidden" name="page" value="wpui-admin" />
    <input type="hidden" name="tab" value="terms" />
    <label>Post ID: <input type="number" name="post_id" value="<?php echo esc_attr($post_id); ?>" /></label>
    <button type="submit" class="button">Consultar</button>
</form>

<?php if ($terms): ?>
<table class="wpui-table">
    <thead>
        <tr>
            <th>Item</th>
            <th>Heading</th>
            <th>Termo</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($terms as $row): ?>
        <tr>
            <td><?php echo esc_html($row['item_key']); ?></td>
            <td><?php echo esc_html($row['heading']); ?></td>
            <td><?php echo esc_html($row['term']); ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php elseif ($post_id): ?>
<p>Nenhum termo encontrado para o post ID <?php echo esc_html($post_id); ?>.</p>
<?php endif; ?>
