<?php
/**
 * WPUI Admin Partial – Dashboard
 * @version 1.0.0
 * @description Painel de indexação com visualização de posts e ações manuais.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;
$posts_table = $wpdb->prefix . 'wpui_posts';
$items_table = $wpdb->prefix . 'wpui_items';

$posts = $wpdb->get_results("SELECT p.post_id, p.mode, p.indexed_at, COUNT(i.id) AS total_terms
    FROM {$posts_table} p
    LEFT JOIN {$items_table} i ON p.post_id = i.post_id
    GROUP BY p.post_id
    ORDER BY p.indexed_at DESC
    LIMIT 50", ARRAY_A);
?>

<h2>Posts Indexados</h2>
<table class="wpui-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Título</th>
            <th>Modo</th>
            <th>Indexado em</th>
            <th>Termos</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($posts as $row): ?>
        <tr>
            <td><?php echo esc_html($row['post_id']); ?></td>
            <td><a href="<?php echo get_edit_post_link($row['post_id']); ?>" target="_blank"><?php echo esc_html(get_the_title($row['post_id'])); ?></a></td>
            <td><?php echo esc_html($row['mode']); ?></td>
            <td><?php echo esc_html($row['indexed_at']); ?></td>
            <td><?php echo esc_html($row['total_terms']); ?></td>
            <td>
                <a href="<?php echo admin_url('admin.php?page=wpui-admin&action=reindex&post_id=' . $row['post_id']); ?>" class="button">Reindexar</a>
                <a href="<?php echo admin_url('admin.php?page=wpui-admin&action=delete_index&post_id=' . $row['post_id']); ?>" class="button">Limpar</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
