<?php
/**
 * Plugin Name: WP Unified Indexer
 * Description: Carrega módulos do plugin, define constantes, e registra hooks de ativação/desativação.
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Constantes globais
define( 'WPUI_VERSION', '1.0.0' );
define( 'WPUI_PLUGIN_FILE', __FILE__ );
define( 'WPUI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPUI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WPUI_CAP', 'manage_wpui' );
define( 'WPUI_OPTION_KEY', 'wpui_settings' );
define( 'WPUI_DB_VERSION', '1.0.0' );

// Carregamento modular e ordenado
require_once WPUI_PLUGIN_DIR . 'includes/db.php';
require_once WPUI_PLUGIN_DIR . 'includes/synonyms.php';
require_once WPUI_PLUGIN_DIR . 'includes/rest.php';
require_once WPUI_PLUGIN_DIR . 'includes/class-wpui-indexer.php';
require_once WPUI_PLUGIN_DIR . 'admin-page-1-enhanced.php';

// Ativação
register_activation_hook( __FILE__, function () {
    WPUI_DB::install_tables();
    $defaults = array(
        'index_mode' => 'auto',
        'start_number' => 5,
        'batch_size' => 50,
        'logging' => false,
        'keep_data_on_uninstall' => true,
    );
    add_option( WPUI_OPTION_KEY, $defaults, '', false );
    update_option( 'wpui_db_version', WPUI_DB_VERSION );
});

// Desativação
register_deactivation_hook( __FILE__, function () {
    // Nenhuma ação crítica
});

// Metabox por post
add_action( 'add_meta_boxes', function () {
    add_meta_box( 'wpui_metabox', 'WP Unified Indexer', function ( $post ) {
        if ( ! current_user_can( 'edit_post', $post->ID ) ) return;
        $val = get_post_meta( $post->ID, '_wpui_force_index', true );
        $mode = get_post_meta( $post->ID, '_wpui_mode', true );
        wp_nonce_field( 'wpui_metabox', 'wpui_metabox_nonce' );
        ?>
        <p><label><input type="checkbox" name="wpui_force_index" value="1" <?php checked( $val, '1' ); ?> /> Forçar reindexação ao salvar</label></p>
        <p>
            <label>Modo para este post:</label><br/>
            <select name="wpui_mode">
                <option value="">(usar global)</option>
                <option value="full" <?php selected( $mode, 'full' ); ?>>Full (post inteiro)</option>
                <option value="items" <?php selected( $mode, 'items' ); ?>>Itens numerados (≥ 5)</option>
            </select>
        </p>
        <?php
    }, 'post', 'side' );
});

// Salvamento do post
add_action( 'save_post', function ( $post_id ) {
    if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    if ( ! isset( $_POST['wpui_metabox_nonce'] ) || ! wp_verify_nonce( $_POST['wpui_metabox_nonce'], 'wpui_metabox' ) ) return;

    $force = isset( $_POST['wpui_force_index'] ) ? '1' : '';
    $mode  = isset( $_POST['wpui_mode'] ) ? sanitize_text_field( $_POST['wpui_mode'] ) : '';

    update_post_meta( $post_id, '_wpui_force_index', $force );
    update_post_meta( $post_id, '_wpui_mode', $mode );

    WPUI_Indexer::schedule_index( (int) $post_id );
}, 10, 1);

// Cron handler
add_action( 'wpui_index_post_event', function ( $post_id ) {
    WPUI_Indexer::index_post( (int) $post_id );
});

// REST API
add_action( 'rest_api_init', [ 'WPUI_REST', 'register_routes' ] );