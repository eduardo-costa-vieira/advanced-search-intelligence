<?php
/**
 * WP Unified Indexer – Uninstall Handler
 * @version 1.0.0 (2025-08-13)
 * @description Remove dados do plugin com segurança, respeitando configuração de preservação.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Carrega opções para verificar se deve manter os dados
$opt = get_option( 'wpui_settings', [] );
$keep = ! empty( $opt['keep_data_on_uninstall'] );

if ( $keep ) {
    // Usuário optou por manter os dados
    return;
}

// Remove tabelas e opções
global $wpdb;

$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wpui_items" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wpui_posts" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wpui_synonyms" );

delete_option( 'wpui_settings' );
delete_option( 'wpui_db_version' );
