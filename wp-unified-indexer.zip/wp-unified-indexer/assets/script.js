document.addEventListener('DOMContentLoaded', function () {
    const progressEl = document.getElementById('wpui-progress');
    if (progressEl) {
        fetch(ajaxurl + '?action=wpui_batch_progress')
            .then(res => res.json())
            .then(data => {
                progressEl.textContent = 'Progresso: ' + data.percent + '% (' + data.done + '/' + data.total + ')';
            });
    }
});
