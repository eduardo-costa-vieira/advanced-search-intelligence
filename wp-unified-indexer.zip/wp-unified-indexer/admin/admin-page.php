<?php
/**
 * WPUI Admin Page Enhanced
 * @version 1.2.0 (2025-08-13)
 * @description Interface administrativa com abas, AJAX, visualização e ações manuais.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WPUI_Admin_Page {

    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('admin_init', [$this, 'process_form_actions']);
        add_action('wp_ajax_wpui_batch_progress', [$this, 'ajax_batch_progress']);
    }

    public function add_admin_menu() {
        add_menu_page(
            'WP Unified Indexer',
            'WPUI',
            'manage_options',
            'wpui-admin',
            [$this, 'render_admin_page'],
            'dashicons-search',
            6
        );
    }

    public function enqueue_scripts($hook) {
        if ($hook !== 'toplevel_page_wpui-admin') return;
        wp_enqueue_script('wpui-script', plugin_dir_url(__FILE__) . '../assets/script.js', ['jquery'], WPUI_VERSION, true);
        wp_localize_script('wpui-script', 'wpui_ajax', ['ajax_url' => admin_url('admin-ajax.php')]);
        wp_enqueue_style('wpui-style', plugin_dir_url(__FILE__) . '../assets/style.css', [], WPUI_VERSION);
    }

    public function process_form_actions() {
        if (!current_user_can('manage_options')) return;

        if (isset($_POST['wpui_action']) && check_admin_referer('wpui_admin_action', 'wpui_nonce')) {
            $action = sanitize_text_field($_POST['wpui_action']);
            $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;

            if ($action === 'index_post_manually' && $post_id > 0) {
                WPUI_Indexer::schedule_index($post_id);
                set_transient('wpui_notice', 'Post agendado para indexação.', 30);
            }

            if ($action === 'deindex_post_manually' && $post_id > 0) {
                WPUI_Indexer::deindex_post($post_id);
                set_transient('wpui_notice', 'Post removido do índice.', 30);
            }

            if ($action === 'run_batch_indexer') {
                $q = new WP_Query([
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'fields' => 'ids',
                    'posts_per_page' => -1,
                    'no_found_rows' => true,
                ]);
                foreach ($q->posts as $pid) {
                    WPUI_Indexer::schedule_index((int)$pid);
                }
                set_transient('wpui_notice', 'Reindexação em lote agendada.', 30);
            }
        }
    }

    public function ajax_batch_progress() {
        if (!current_user_can('manage_options')) wp_send_json_error('Sem permissão');
        $count = get_transient('wpui_batch_count') ?: 0;
        wp_send_json_success(['count' => $count]);
    }

    public function render_admin_page() {
        $tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'dashboard';
        $notice = get_transient('wpui_notice');
        if ($notice) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($notice) . '</p></div>';
            delete_transient('wpui_notice');
        }

        echo '<div class="wrap"><h1>WP Unified Indexer</h1>';
        echo '<nav class="nav-tab-wrapper">';
        echo '<a href="?page=wpui-admin&tab=dashboard" class="nav-tab ' . ($tab === 'dashboard' ? 'nav-tab-active' : '') . '">Painel de Indexação</a>';
        echo '<a href="?page=wpui-admin&tab=terms" class="nav-tab ' . ($tab === 'terms' ? 'nav-tab-active' : '') . '">Termos Relacionados</a>';
        echo '</nav><div class="wpui-tab-content">';

        if ($tab === 'terms') {
            include plugin_dir_path(__FILE__) . '../partials/terms.php';
        } else {
            include plugin_dir_path(__FILE__) . '../partials/dashboard.php';
        }

        echo '</div></div>';
    }
}

new WPUI_Admin_Page();
?>
